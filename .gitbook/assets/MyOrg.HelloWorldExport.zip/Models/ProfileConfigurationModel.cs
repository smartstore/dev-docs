﻿using System;
using Smartstore.Web.Modelling;

namespace MyOrg.HelloWorld.Models
{
    [Serializable, CustomModelPart]
    public class ProfileConfigurationModel
    {
        [LocalizedDisplay("Plugins.MyOrg.HelloWorld.NumberOfExportedRows")]
        public int NumberOfExportedRows { get; set; } = 10;
    }
}